def lambda_function():
    print("hellow world")
